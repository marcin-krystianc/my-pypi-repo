# Auto-generated package metadata
__package__ = 'jollyjack'
__version__ = '0.14.2'
__dependencies__ = ['pyarrow~=19.0.0', 'numpy>=1.16.6']
